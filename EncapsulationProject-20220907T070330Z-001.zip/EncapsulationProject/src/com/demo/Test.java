package com.demo;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
	     Scanner scanner = new Scanner(System.in);
	     System.out.println("Enter Id>>");
	     int userId = scanner.nextInt();
	     
	     System.out.println("Enter Name>>");
	    // scanner.nextLine();
	     String userName = scanner.toString();
	  
	     System.out.println("Enter Salary>>");
	     int userSalary = scanner.nextInt();
	     
	     Employee emp = new Employee();
	     //setting the values
	     emp.setId(userId);
	     
	     emp.setName(userName);
	     
	     emp.setSalary(userSalary);
	     
	     //getting the values
	     
	     int id=emp.getId();
	     String name=emp.getName();
	     int salary=emp.getSalary();
	     
	     System.out.println("Employee details>>");
	     System.out.println("Id="+id);
	     System.out.println("Name="+name);
	     System.out.println("Salary="+emp.getSalary());
	     
	     
	     
		
		

	}

}
